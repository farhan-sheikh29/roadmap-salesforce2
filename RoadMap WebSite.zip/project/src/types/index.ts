export interface DayContent {
  day: number;
  title: string;
  topics: string[];
  completed: boolean;
}