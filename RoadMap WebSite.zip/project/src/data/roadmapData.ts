import { DayContent } from '../types';

export const roadmapData: DayContent[] = [
  {
    day: 1,
    title: "Apex Best Practices",
    topics: [
      "Write a bulkified trigger to handle insert/update on Contact.",
      "Avoid SOQL inside for loop – rewrite sample logic.",
      "Design a utility class to reuse common methods across triggers.",
      "Create an Apex class using proper naming conventions and comments.",
      "Implement error handling with try-catch block.",
      "Write a method that performs both DML and SOQL, and separate concerns.",
      "Use of final and static keywords in Apex with examples.",
      "Explain and use 'with sharing' vs 'without sharing' keywords.",
      "Refactor a trigger to use a handler pattern.",
      "Show a use case for recursive trigger prevention."
    ],
    completed: true
  },
  {
    day: 2,
    title: "Advanced SOQL",
    topics: [
      "Query all Contacts related to an Account using relationship queries.",
      "Use aggregate SOQL to find total opportunities per account.",
      "Use subqueries to pull related Cases under an Account.",
      "Use GROUP BY to count Leads by status.",
      "Use HAVING to filter aggregate results.",
      "Create a query to fetch top 5 Accounts by Opportunity amount.",
      "Explain and use TYPEOF in SELECT statements.",
      "Use LIMIT and OFFSET in queries and explain when they are useful.",
      "Write a query that gets related Owner.Name in Opportunity.",
      "Write a query using IN operator for filtering specific Ids."
    ],
    completed: false
  },
  {
    day: 3,
    title: "Map & Set Practice",
    topics: [
      "Extract unique email addresses from Contact list using Set.",
      "Before inserting Contacts, filter existing AccountIds using Set<Id>.",
      "Map Account Names to Ids using Map<String, Id>.",
      "Map User.Id to List<Project__c> from two separate lists.",
      "Compare old and new Contact lists using Map<Id, Contact>.",
      "Create Set of all unique Billing Cities from Account list.",
      "Group Leads by Status using Map<String, List<Lead>>.",
      "Map Account Id to List<Contact>.",
      "Avoid inserting duplicate Contacts using Set<String> for emails.",
      "Map Contact Ids to Owner Name using SOQL and Map."
    ],
    completed: false
  },
  {
    day: 4,
    title: "Triggers & Trigger Framework",
    topics: [
      "Write a trigger on Contact for insert and update.",
      "Implement a trigger handler pattern class.",
      "Write test data and validate trigger handler execution.",
      "Design logic to call different methods based on context (insert/update/delete).",
      "Write recursive trigger prevention logic.",
      "Use static variables for multi-trigger execution control.",
      "Bulkify a trigger to handle 200 records.",
      "Separate logic in handler class from trigger file.",
      "Use context variables to control logic.",
      "Explain order of execution with sample debug logs."
    ],
    completed: false
  },
  {
    day: 5,
    title: "Future vs Queueable Apex – Scenario-Based Practice",
    topics: [
      "You've been asked to notify 1000 contacts via email whenever a new Product is added. However, this should not slow down the main transaction. What Apex feature would you use, and how would you ensure emails are sent asynchronously without hitting limits?",
      "Imagine you need to update thousands of Opportunity records based on a set of business rules, but the logic is too heavy to run synchronously. What Apex approach would you take and why? How would you design the class to handle large volumes of data?",
      "Your client wants to perform 3 sequential updates across multiple objects: First update Accounts, then related Contacts, and finally log the changes. Each step depends on the previous one completing successfully. How would you structure your Apex classes to accomplish this flow asynchronously?",
      "You're working on a system that currently uses @future methods for updating related Leads after a Campaign is inserted. However, you now need to chain this with a second job to update Campaign Members. How would you modify the existing code to support this requirement?",
      "Your trigger fires a future method, but now business requires you to pass a complex object or multiple parameters into the asynchronous job. You encounter limitations with @future. What would be a better alternative, and how would you implement it?",
      "After a user uploads a large set of files via a custom component, you want to enqueue a job to update the Document_Status__c field on related custom records. How would you enqueue this operation and ensure it is processed without performance issues?",
      "A Queueable job you've created isn't completing successfully, but the logs don't show clear errors. What debugging strategy would you implement inside the Queueable class to understand what's going wrong post-deployment?"
    ],
    completed: false
  },
  {
    day: 6,
    title: "Batch Apex",
    topics: [
      "You need to update thousands of Contact records with new data pulled from Accounts. How would you implement this efficiently?",
      "A user uploads a file with 100,000 Account records. How do you process this without hitting limits?",
      "You want to run a batch job weekly to clean up inactive records. How do you design your batch class and schedule it?",
      "You need to group records by criteria and update them in chunks. How will you structure your batch?",
      "Your batch class is failing after 10,000 records. How will you debug and fix the issue?"
    ],
    completed: false
  },
  {
    day: 7,
    title: "Scheduled Apex",
    topics: [
      "Your manager asks for an automated job that runs every Friday at 6 AM to update stale Leads. How would you implement this?",
      "You have a batch process that should only run on the first of every month. How can you schedule it?",
      "A job needs to email Account Managers a summary of upcoming renewals each week. How would you use Scheduled Apex to handle this?",
      "Your batch is scheduled but sometimes overlaps with another job. How can you control this?",
      "The business wants to pause a scheduled job temporarily. What's the cleanest way to manage this?"
    ],
    completed: false
  },
  {
    day: 8,
    title: "Test Class Best Practices",
    topics: [
      "Your test class is failing because of dependency on live data. How do you fix this?",
      "Your manager asks you to validate that no extra records are inserted in a trigger. How will you write such an assertion?",
      "You need to test an asynchronous batch job. What Apex methods will you use?",
      "You have 5 test classes with similar data setup. How would you make the setup reusable?",
      "Your code coverage is 100%, but there are no assertions. What does that mean and how do you fix it?"
    ],
    completed: false
  },
  {
    day: 9,
    title: "Test Data Factory",
    topics: [
      "Your org has multiple test classes setting up the same Account and Contact data. How can you centralize this?",
      "You want to test different edge cases like null values, inactive users, etc. How can a test data factory help?",
      "Your test classes take too long to run. How can refactoring your test data speed them up?",
      "You need different types of Opportunities (Closed Won, Open). How will you build a reusable method for this?",
      "A junior developer duplicated 20 lines of data creation in every test class. How do you enforce test data factory usage?"
    ],
    completed: false
  },
  {
    day: 10,
    title: "Error Handling & Logging",
    topics: [
      "A trigger fails silently in production. How will you capture the error details for investigation?",
      "Your code needs to handle a DML exception but also notify an admin. How would you structure this?",
      "You want to track every exception in a custom object. How would you design this?",
      "A job is intermittently failing. How would you add context-specific logs to catch the failure reason?",
      "You have a helper class that fails often. How can you catch and log errors without breaking the flow?"
    ],
    completed: false
  },
  {
    day: 11,
    title: "Security in Apex",
    topics: [
      "Your Apex class queries Contact data, but users without permission see blank fields. Why, and how do you fix it?",
      "You want to enforce field-level security in a SOQL query. How would you do this?",
      "Your code exposes sensitive data via a public method. How can you secure it?",
      "You are writing an Apex controller for a public-facing community site. How do you ensure it doesn't expose unauthorized data?",
      "You're unsure if a user has access to an object before performing DML. How can you check programmatically?"
    ],
    completed: false
  },
  {
    day: 12,
    title: "Real-Time Mini Project – Part 1",
    topics: [
      "You are designing a new object Training__c and need to auto-update the number of trainees whenever a new trainee is added. What design pattern would you use?",
      "You want to validate that a Training session doesn't exceed 20 trainees. How do you implement this using Apex logic?",
      "Every time a Training is updated, you want to send a summary email to the Trainer. What async mechanism would you use?",
      "Your trigger logic is getting complex. How would you divide and structure it using a framework?",
      "How would you design your test data to cover both standard and edge use cases?"
    ],
    completed: false
  },
  {
    day: 13,
    title: "Real-Time Mini Project – Part 2",
    topics: [
      "You want to implement a retry mechanism in your async job in case of failure. How can you design this in Apex?",
      "You have multiple triggers and async jobs running in your mini-project. How would you log the outcomes and track failures?",
      "Your batch job updates related records, but some data is skipped. How do you capture and log skipped records?",
      "You want to simulate failure scenarios in your test class. How would you write such a test?",
      "Your manager asks for a system report showing errors, job executions, and test results. How would you approach this?"
    ],
    completed: false
  },
  {
    day: 14,
    title: "Code Review & Optimization",
    topics: [
      "You review someone else's trigger code and see DML inside loops. How do you suggest improvements?",
      "You find that the same logic is written in three classes. What's your refactoring strategy?",
      "Your Apex class exceeds 10,000 lines. What's your optimization plan?",
      "The code you inherited doesn't follow naming conventions. How would you proceed?",
      "How do you evaluate if a trigger or class is bulk-safe and scalable?"
    ],
    completed: false
  },
  {
    day: 15,
    title: "Mock Test + Feedback",
    topics: [
      "You're given an Apex class and asked to identify bugs. What approach do you take?",
      "A question asks you to predict the output of a trigger firing during update. What key points will you consider?",
      "You're asked what happens if a Queueable job is enqueued from another Queueable job. What are the rules?",
      "You're shown a class using without sharing and asked if it's secure. What do you check?",
      "You need to explain how Test.startTest() and Test.stopTest() work. What's their significance in async testing?"
    ],
    completed: false
  }
];