import React, { useState, useEffect } from 'react';
import { roadmapData } from './data/roadmapData';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import DayDetail from './components/DayDetail';
import ProgressBar from './components/ProgressBar';
import Footer from './components/Footer';
import SearchResults from './components/SearchResults';

function App() {
  const [days, setDays] = useState(roadmapData);
  const [activeDayIndex, setActiveDayIndex] = useState(0);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Load saved progress from localStorage
  useEffect(() => {
    const savedProgress = localStorage.getItem('apexTrainingProgress');
    if (savedProgress) {
      try {
        const parsedProgress = JSON.parse(savedProgress);
        setDays(days.map((day, index) => ({
          ...day,
          completed: parsedProgress[index] || false
        })));
      } catch (e) {
        console.error('Error loading saved progress', e);
      }
    }
  }, []);

  // Save progress to localStorage when it changes
  useEffect(() => {
    const progressToSave = days.map(day => day.completed);
    localStorage.setItem('apexTrainingProgress', JSON.stringify(progressToSave));
  }, [days]);

  const handleToggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleNavigate = (direction: 'prev' | 'next') => {
    if (direction === 'prev' && activeDayIndex > 0) {
      setActiveDayIndex(activeDayIndex - 1);
    } else if (direction === 'next' && activeDayIndex < days.length - 1) {
      setActiveDayIndex(activeDayIndex + 1);
    }
  };

  const hasPrev = activeDayIndex > 0;
  const hasNext = activeDayIndex < days.length - 1;

  return (
    <div className="min-h-screen flex flex-col bg-gray-100 dark:bg-gray-950 text-gray-900 dark:text-gray-100 transition-colors duration-200">
      <Header 
        toggleSidebar={handleToggleSidebar} 
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
      />
      
      <div className="flex-1 flex overflow-hidden">
        <Sidebar 
          days={days}
          activeDayIndex={activeDayIndex}
          setActiveDayIndex={setActiveDayIndex}
          isOpen={sidebarOpen}
          searchTerm={searchTerm}
        />
        
        <main 
          className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8"
          onClick={() => setSidebarOpen(false)}
        >
          <div className="max-w-3xl mx-auto">
            <ProgressBar days={days} />
            
            {searchTerm ? (
              <SearchResults 
                searchTerm={searchTerm}
                days={days}
                setActiveDayIndex={(index) => {
                  setActiveDayIndex(index);
                  setSearchTerm('');
                }}
              />
            ) : (
              <DayDetail 
                day={days[activeDayIndex]}
                onNavigate={handleNavigate}
                hasPrev={hasPrev}
                hasNext={hasNext}
              />
            )}
          </div>
        </main>
      </div>
      
      <Footer />

      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 z-10 bg-gray-600 bg-opacity-50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        ></div>
      )}
    </div>
  );
}

export default App;