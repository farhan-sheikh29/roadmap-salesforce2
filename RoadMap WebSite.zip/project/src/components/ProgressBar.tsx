import React from 'react';
import { DayContent } from '../types';

interface ProgressBarProps {
  days: DayContent[];
}

const ProgressBar: React.FC<ProgressBarProps> = ({ days }) => {
  const completedDays = days.filter(day => day.completed).length;
  const totalDays = days.length;
  const progressPercentage = totalDays > 0 ? Math.round((completedDays / totalDays) * 100) : 0;

  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">
          Your Progress
        </h3>
        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
          {completedDays} of {totalDays} days completed
        </span>
      </div>
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 overflow-hidden">
        <div 
          className="bg-blue-600 h-2.5 rounded-full transition-all duration-500 ease-out"
          style={{ width: `${progressPercentage}%` }}
        ></div>
      </div>
      <div className="mt-2 text-right">
        <span className="text-sm font-medium text-blue-600 dark:text-blue-400">
          {progressPercentage}%
        </span>
      </div>
    </div>
  );
};

export default ProgressBar;