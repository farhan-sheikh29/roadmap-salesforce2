import React from 'react';
import { CheckCircle, Circle } from 'lucide-react';
import { DayContent } from '../types';

interface SidebarProps {
  days: DayContent[];
  activeDayIndex: number;
  setActiveDayIndex: (index: number) => void;
  isOpen: boolean;
  searchTerm: string;
}

const Sidebar: React.FC<SidebarProps> = ({
  days,
  activeDayIndex,
  setActiveDayIndex,
  isOpen,
  searchTerm
}) => {
  const filteredDays = searchTerm
    ? days.filter(day => {
        const searchTermLower = searchTerm.toLowerCase();
        return (
          day.title.toLowerCase().includes(searchTermLower) ||
          day.topics.some(topic => topic.toLowerCase().includes(searchTermLower))
        );
      })
    : days;

  return (
    <aside 
      className={`fixed inset-y-0 left-0 z-20 transform ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      } lg:relative lg:translate-x-0 w-64 bg-gray-50 dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 overflow-y-auto transition-transform duration-200 ease-in-out`}
    >
      <div className="py-6">
        <div className="px-6 mb-6">
          <h2 className="text-lg font-medium text-gray-900 dark:text-white">15-Day Roadmap</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Track your Apex development journey</p>
        </div>
        
        <nav className="space-y-1 px-3">
          {filteredDays.map((day, index) => (
            <button
              key={day.day}
              className={`flex items-center px-3 py-2 text-sm font-medium rounded-md w-full transition-all duration-150 ${
                activeDayIndex === index
                  ? 'bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700/50'
              }`}
              onClick={() => setActiveDayIndex(index)}
            >
              <div className="flex items-center">
                {day.completed ? (
                  <CheckCircle size={18} className="text-green-500 mr-2" />
                ) : (
                  <Circle size={18} className="text-gray-400 mr-2" />
                )}
                <span>Day {day.day}: {day.title}</span>
              </div>
            </button>
          ))}
          
          {filteredDays.length === 0 && (
            <div className="px-3 py-2 text-sm text-gray-500 dark:text-gray-400">
              No matches found for "{searchTerm}"
            </div>
          )}
        </nav>
      </div>
    </aside>
  );
};

export default Sidebar;