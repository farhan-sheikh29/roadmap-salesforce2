import React from 'react';
import { Github, Twitter, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <p className="text-sm text-gray-500 dark:text-gray-400">
              © 2025 Apex Developer Training Plan. All rights reserved.
            </p>
          </div>
          
          <div className="flex space-x-6">
            <a 
              href="#" 
              className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300 transition-colors duration-150"
            >
              <span className="sr-only">Github</span>
              <Github size={20} />
            </a>
            <a 
              href="#" 
              className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300 transition-colors duration-150"
            >
              <span className="sr-only">Twitter</span>
              <Twitter size={20} />
            </a>
            <a 
              href="#" 
              className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300 transition-colors duration-150"
            >
              <span className="sr-only">Email</span>
              <Mail size={20} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;