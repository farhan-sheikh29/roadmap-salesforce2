import React from 'react';
import { DayContent } from '../types';

interface SearchResultsProps {
  searchTerm: string;
  days: DayContent[];
  setActiveDayIndex: (index: number) => void;
}

const SearchResults: React.FC<SearchResultsProps> = ({ searchTerm, days, setActiveDayIndex }) => {
  if (!searchTerm) return null;

  const searchTermLower = searchTerm.toLowerCase();
  
  // Find days matching the search term in title or topics
  const matchingDays = days.map((day, index) => {
    const matchesTitle = day.title.toLowerCase().includes(searchTermLower);
    const matchingTopics = day.topics.filter(topic => 
      topic.toLowerCase().includes(searchTermLower)
    );
    
    if (matchesTitle || matchingTopics.length > 0) {
      return { day, index, matchingTopics };
    }
    return null;
  }).filter(Boolean);

  if (matchingDays.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <p className="text-gray-600 dark:text-gray-400">No results found for "{searchTerm}"</p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
      <div className="p-6">
        <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
          Search Results for "{searchTerm}"
        </h2>
        
        <div className="space-y-4">
          {matchingDays.map(result => (
            <div 
              key={result.day.day}
              className="p-4 rounded-md bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:border-blue-300 dark:hover:border-blue-700 transition-all duration-200 cursor-pointer"
              onClick={() => setActiveDayIndex(result.index)}
            >
              <h3 className="font-medium text-gray-900 dark:text-white mb-2">
                Day {result.day.day}: {result.day.title}
              </h3>
              
              {result.matchingTopics && result.matchingTopics.length > 0 && (
                <div className="mt-2 space-y-2">
                  <p className="text-sm text-gray-500 dark:text-gray-400">Matching topics:</p>
                  {result.matchingTopics.map((topic, i) => (
                    <p key={i} className="text-sm text-gray-800 dark:text-gray-200 ml-2">
                      • {topic}
                    </p>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SearchResults;