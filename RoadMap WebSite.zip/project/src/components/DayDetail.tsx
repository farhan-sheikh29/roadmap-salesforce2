import React from 'react';
import { DayContent } from '../types';
import { Calendar, ArrowLeft, ArrowRight } from 'lucide-react';

interface DayDetailProps {
  day: DayContent;
  onNavigate: (direction: 'prev' | 'next') => void;
  hasPrev: boolean;
  hasNext: boolean;
}

const DayDetail: React.FC<DayDetailProps> = ({ 
  day, 
  onNavigate,
  hasPrev,
  hasNext
}) => {
  return (
    <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden transition-colors duration-200">
      <div className="p-6 sm:p-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 mr-4">
              <Calendar size={20} />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
                Day {day.day}: {day.title}
              </h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                {day.topics.length} topics to complete
              </p>
            </div>
          </div>
          <div className={`px-4 py-2 rounded-md text-sm font-medium ${
            day.completed 
              ? 'bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-400'
              : 'bg-yellow-100 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-400'
          }`}>
            {day.completed ? 'Completed' : 'Pending'}
          </div>
        </div>

        <div className="space-y-4 mb-8">
          {day.topics.map((topic, index) => (
            <div 
              key={index}
              className="p-4 rounded-md bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 transition-all duration-200 hover:border-blue-300 dark:hover:border-blue-700"
            >
              <p className="text-gray-800 dark:text-gray-200">{topic}</p>
            </div>
          ))}
        </div>
        
        <div className="flex justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
          <button
            onClick={() => onNavigate('prev')}
            disabled={!hasPrev}
            className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors duration-150 focus:outline-none ${
              hasPrev 
                ? 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800' 
                : 'text-gray-400 dark:text-gray-600 cursor-not-allowed'
            }`}
          >
            <ArrowLeft size={16} className="mr-2" />
            Previous Day
          </button>
          
          <button
            onClick={() => onNavigate('next')}
            disabled={!hasNext}
            className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors duration-150 focus:outline-none ${
              hasNext 
                ? 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800' 
                : 'text-gray-400 dark:text-gray-600 cursor-not-allowed'
            }`}
          >
            Next Day
            <ArrowRight size={16} className="ml-2" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default DayDetail;